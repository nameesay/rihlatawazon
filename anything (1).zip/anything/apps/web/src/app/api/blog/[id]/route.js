import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  const { id } = params;
  try {
    const [post] =
      await sql`SELECT * FROM blog_posts WHERE id = ${id} OR slug = ${id}`;
    if (!post) {
      return Response.json({ error: "Post not found" }, { status: 404 });
    }
    const comments =
      await sql`SELECT * FROM blog_comments WHERE post_id = ${post.id} AND approved = true ORDER BY created_at DESC`;
    return Response.json({ ...post, comments });
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to fetch post" }, { status: 500 });
  }
}

import sql from "@/app/api/utils/sql";

export async function POST(request, { params }) {
  const { id } = params;
  try {
    const { author_name, comment_text } = await request.json();
    if (!author_name || !comment_text) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }
    const [comment] = await sql`
      INSERT INTO blog_comments (post_id, author_name, comment_text)
      VALUES (${id}, ${author_name}, ${comment_text})
      RETURNING *
    `;
    return Response.json(comment);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to add comment" }, { status: 500 });
  }
}

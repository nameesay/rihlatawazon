import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const category = searchParams.get("category");
  const search = searchParams.get("search");

  try {
    let query = "SELECT * FROM blog_posts WHERE 1=1";
    const params = [];

    if (category) {
      params.push(category);
      query += ` AND category = $${params.length}`;
    }

    if (search) {
      params.push(`%${search}%`);
      query += ` AND (title ILIKE $${params.length} OR content ILIKE $${params.length})`;
    }

    query += " ORDER BY created_at DESC";

    const posts = await sql(query, params);
    return Response.json(posts);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to fetch posts" }, { status: 500 });
  }
}

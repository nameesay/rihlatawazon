import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { name, phone, interest_level } = await request.json();
    if (!name || !phone || !interest_level) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }
    const [lead] = await sql`
      INSERT INTO leads (name, phone, interest_level)
      VALUES (${name}, ${phone}, ${interest_level})
      RETURNING *
    `;
    return Response.json(lead);
  } catch (error) {
    console.error(error);
    return Response.json({ error: "Failed to save lead" }, { status: 500 });
  }
}

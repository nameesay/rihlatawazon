import React, { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ReactMarkdown from "react-markdown";
import { toast, Toaster } from "sonner";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Calendar, User, MessageCircle, Send, ArrowRight } from "lucide-react";

export default function BlogPostPage({ params }) {
  const { id } = params;
  const queryClient = useQueryClient();
  const [commentName, setCommentName] = useState("");
  const [commentText, setCommentText] = useState("");

  const { data: post, isLoading } = useQuery({
    queryKey: ["blog-post", id],
    queryFn: async () => {
      const res = await fetch(`/api/blog/${id}`);
      if (!res.ok) throw new Error("Post not found");
      return res.json();
    },
  });

  const commentMutation = useMutation({
    mutationFn: async (newComment) => {
      const res = await fetch(`/api/blog/${post.id}/comments`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newComment),
      });
      if (!res.ok) throw new Error("Failed to post comment");
      return res.json();
    },
    onSuccess: () => {
      toast.success("تم إرسال تعليقك! سيظهر بعد مراجعة الإدارة.");
      setCommentName("");
      setCommentText("");
      queryClient.invalidateQueries(["blog-post", id]);
    },
    onError: () => {
      toast.error("حدث خطأ أثناء إرسال التعليق.");
    },
  });

  const handleCommentSubmit = (e) => {
    e.preventDefault();
    if (!commentName || !commentText) return;
    commentMutation.mutate({
      author_name: commentName,
      comment_text: commentText,
    });
  };

  if (isLoading)
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-[#D4AF37] border-t-transparent rounded-full animate-spin" />
      </div>
    );

  if (!post)
    return (
      <div className="min-h-screen bg-[#0A0A0B] flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-4xl text-[#E5E0D8] mb-4">المقال غير موجود</h1>
          <a
            href="/blog"
            className="text-[#D4AF37] hover:underline flex items-center justify-center gap-2"
          >
            العودة للمدونة <ArrowRight size={20} />
          </a>
        </div>
      </div>
    );

  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      <Toaster position="top-center" richColors />
      <Navbar />

      <header className="relative h-[60vh] flex items-end justify-center pt-40 overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src={
              post.image_url ||
              "https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop"
            }
            className="w-full h-full object-cover"
            alt={post.title}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B] via-[#0A0A0B]/60 to-transparent" />
        </div>
        <div className="relative z-10 max-w-4xl mx-auto px-6 pb-12 text-center">
          <div className="flex justify-center gap-6 text-[#D4AF37] text-sm font-bold uppercase tracking-widest mb-6">
            <span className="flex items-center gap-2">
              <Calendar size={16} />{" "}
              {new Date(post.created_at).toLocaleDateString("ar-MA")}
            </span>
            <span className="flex items-center gap-2">
              <User size={16} /> القائد
            </span>
            <span className="flex items-center gap-2">
              <MessageCircle size={16} /> {post.comments?.length || 0} تعليقات
            </span>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-[#E5E0D8] font-amiri leading-tight mb-4">
            {post.title}
          </h1>
          <div className="w-20 h-1 bg-[#D4AF37] mx-auto" />
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-6 py-20">
        {/* Article Content */}
        <div className="prose prose-invert prose-gold max-w-none text-[#E5E0D8]/90 leading-loose text-lg mb-20 font-light">
          <ReactMarkdown
            components={{
              h2: ({ node, ...props }) => (
                <h2
                  className="text-3xl font-bold text-[#E5E0D8] mt-12 mb-6 font-amiri"
                  {...props}
                />
              ),
              p: ({ node, ...props }) => <p className="mb-8" {...props} />,
              strong: ({ node, ...props }) => (
                <strong className="text-[#D4AF37] font-bold" {...props} />
              ),
              li: ({ node, ...props }) => (
                <li
                  className="mb-2 list-disc list-inside marker:text-[#D4AF37]"
                  {...props}
                />
              ),
            }}
          >
            {post.content}
          </ReactMarkdown>
        </div>

        {/* Comments Section */}
        <section className="pt-20 border-t border-[#D4AF37]/10">
          <h3 className="text-3xl font-bold text-[#E5E0D8] mb-12 font-amiri flex items-center gap-4">
            التعليقات{" "}
            <span className="text-sm px-3 py-1 bg-[#D4AF37]/10 text-[#D4AF37] rounded-full">
              {post.comments?.length || 0}
            </span>
          </h3>

          <div className="space-y-8 mb-20">
            {post.comments?.map((comment) => (
              <div
                key={comment.id}
                className="p-8 bg-[#111112] border border-[#D4AF37]/10 rounded-3xl"
              >
                <div className="flex justify-between items-center mb-4">
                  <h5 className="font-bold text-[#D4AF37] text-lg">
                    {comment.author_name}
                  </h5>
                  <span className="text-xs text-[#E5E0D8]/40">
                    {new Date(comment.created_at).toLocaleDateString("ar-MA")}
                  </span>
                </div>
                <p className="text-[#E5E0D8]/70 leading-relaxed">
                  {comment.comment_text}
                </p>
              </div>
            ))}
            {post.comments?.length === 0 && (
              <p className="text-[#E5E0D8]/40 text-center italic">
                لا توجد تعليقات بعد. كن أول من يعلق!
              </p>
            )}
          </div>

          {/* Comment Form */}
          <div className="bg-[#111112] p-8 md:p-12 rounded-3xl border border-[#D4AF37]/20 shadow-2xl">
            <h4 className="text-2xl font-bold text-[#E5E0D8] mb-8 font-amiri">
              اترك تعليقاً
            </h4>
            <form onSubmit={handleCommentSubmit} className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[#E5E0D8]/60 text-sm mb-2 font-bold">
                    الاسم
                  </label>
                  <input
                    type="text"
                    value={commentName}
                    onChange={(e) => setCommentName(e.target.value)}
                    required
                    className="w-full bg-[#0A0A0B] border border-[#D4AF37]/20 rounded-xl px-6 py-3 text-[#E5E0D8] outline-none focus:border-[#D4AF37]"
                    placeholder="اسمك الكامل"
                  />
                </div>
              </div>
              <div>
                <label className="block text-[#E5E0D8]/60 text-sm mb-2 font-bold">
                  التعليق
                </label>
                <textarea
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  required
                  rows={4}
                  className="w-full bg-[#0A0A0B] border border-[#D4AF37]/20 rounded-xl px-6 py-4 text-[#E5E0D8] outline-none focus:border-[#D4AF37] resize-none"
                  placeholder="اكتب تعليقك هنا..."
                />
              </div>
              <button
                type="submit"
                disabled={commentMutation.isPending}
                className="bg-[#D4AF37] text-[#0A0A0B] px-10 py-4 rounded-xl font-bold hover:bg-[#F1D592] transition-all flex items-center justify-center gap-2 disabled:opacity-50"
              >
                {commentMutation.isPending
                  ? "جاري الإرسال..."
                  : "إرسال التعليق"}{" "}
                <Send size={20} />
              </button>
            </form>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}

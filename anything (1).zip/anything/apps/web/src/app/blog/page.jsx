import React, { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";
import { Search, Calendar, User, ArrowLeft } from "lucide-react";

export default function BlogListPage() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("");

  const { data: posts, isLoading } = useQuery({
    queryKey: ["blog-posts", search, category],
    queryFn: async () => {
      const params = new URLSearchParams();
      if (search) params.append("search", search);
      if (category) params.append("category", category);
      const res = await fetch(`/api/blog?${params.toString()}`);
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  const categories = ["الكل", "بداية", "قيادة", "منتجات", "صحة"];

  return (
    <div className="min-h-screen bg-[#0A0A0B]">
      <Navbar />

      <header className="pt-40 pb-20 bg-[#111112] border-b border-[#D4AF37]/10">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <h1 className="text-5xl md:text-6xl font-bold text-[#E5E0D8] mb-6 font-amiri">
            المدونة المعرفية
          </h1>
          <p className="text-[#E5E0D8]/60 text-xl max-w-2xl mx-auto">
            مقالات حصرية، نصائح قيادية، وقصص نجاح ملهمة من قلب المغرب.
          </p>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-16">
        {/* Filters */}
        <div className="flex flex-col md:flex-row gap-8 mb-16 justify-between items-center">
          <div className="flex gap-4 overflow-x-auto pb-2 no-scrollbar w-full md:w-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setCategory(cat === "الكل" ? "" : cat)}
                className={`px-6 py-2 rounded-full text-sm font-bold transition-all whitespace-nowrap ${
                  category === cat || (cat === "الكل" && !category)
                    ? "bg-[#D4AF37] text-[#0A0A0B]"
                    : "border border-[#D4AF37]/20 text-[#E5E0D8]/60 hover:border-[#D4AF37]"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full md:w-96">
            <Search
              className="absolute right-4 top-1/2 -translate-y-1/2 text-[#D4AF37]"
              size={20}
            />
            <input
              type="text"
              placeholder="ابحث عن موضوع..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-[#111112] border border-[#D4AF37]/20 rounded-xl px-12 py-3 text-[#E5E0D8] outline-none focus:border-[#D4AF37]"
            />
          </div>
        </div>

        {/* Posts Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div
                key={i}
                className="h-96 bg-[#111112] animate-pulse rounded-3xl"
              />
            ))}
          </div>
        ) : posts?.length === 0 ? (
          <div className="text-center py-20">
            <h3 className="text-2xl text-[#E5E0D8]/60">
              لم يتم العثور على مقالات تطابق بحثك.
            </h3>
          </div>
        ) : (
          <div className="grid md:grid-cols-3 gap-8">
            {posts?.map((post) => (
              <article
                key={post.id}
                className="group bg-[#111112] border border-[#D4AF37]/10 rounded-3xl overflow-hidden hover:border-[#D4AF37]/40 transition-all"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={
                      post.image_url ||
                      "https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop"
                    }
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-8">
                  <span className="inline-block px-3 py-1 bg-[#D4AF37]/10 text-[#D4AF37] text-xs font-bold rounded-full mb-4 uppercase">
                    {post.category}
                  </span>
                  <h2 className="text-2xl font-bold text-[#E5E0D8] mb-4 font-amiri group-hover:text-[#D4AF37] transition-colors">
                    {post.title}
                  </h2>
                  <p className="text-[#E5E0D8]/60 text-sm mb-6 line-clamp-3">
                    {post.excerpt}
                  </p>
                  <div className="flex justify-between items-center">
                    <div className="text-xs text-[#E5E0D8]/40 flex gap-4">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} />{" "}
                        {new Date(post.created_at).toLocaleDateString("ar-MA")}
                      </span>
                    </div>
                    <a
                      href={`/blog/${post.slug}`}
                      className="text-[#D4AF37] font-bold text-sm flex items-center gap-1 hover:underline"
                    >
                      اقرأ المزيد <ArrowLeft size={16} />
                    </a>
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <Footer />
    </div>
  );
}

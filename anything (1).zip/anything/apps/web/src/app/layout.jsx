import { QueryClient, QueryClientProvider } from "@tanstack/react-query";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5, // 5 minutes
      cacheTime: 1000 * 60 * 30, // 30 minutes
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout({ children }) {
  return (
    <html lang="ar" dir="rtl">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=Amiri:wght@400;700&family=IBM+Plex+Sans+Arabic:wght@300;400;600;700&display=swap"
          rel="stylesheet"
        />
        <style>{`
          body {
            background-color: #0A0A0B;
            color: #E5E0D8;
            margin: 0;
            padding: 0;
            font-family: 'IBM Plex Sans Arabic', sans-serif;
          }
          h1, h2, h3, h4, h5, h6 {
            font-family: 'Amiri', serif;
          }
          @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
          }
          .animate-fade-in {
            animation: fadeIn 1s ease-out forwards;
          }
          .gold-gradient {
            background: linear-gradient(45deg, #D4AF37, #F1D592, #D4AF37);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
          }
          ::-webkit-scrollbar {
            width: 8px;
          }
          ::-webkit-scrollbar-track {
            background: #0A0A0B;
          }
          ::-webkit-scrollbar-thumb {
            background: #D4AF37;
            border-radius: 4px;
          }
          html {
            scroll-behavior: smooth;
          }
        `}</style>
      </head>
      <body>
        <QueryClientProvider client={queryClient}>
          {children}
        </QueryClientProvider>
      </body>
    </html>
  );
}

import React from "react";
import { Toaster } from "sonner";
import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Stats from "@/components/Stats";
import Services from "@/components/Services";
import Resources from "@/components/Resources";
import Testimonials from "@/components/Testimonials";
import LeadForm from "@/components/LeadForm";
import BlogPreview from "@/components/BlogPreview";
import BusinessMap from "@/components/Map";
import Footer from "@/components/Footer";

export default function HomePage() {
  return (
    <main className="min-h-screen bg-[#0A0A0B]">
      <Toaster position="top-center" expand={false} richColors />
      <Navbar />
      <Hero />
      <About />
      <Stats />
      <Services />
      <Resources />
      <Testimonials />
      <LeadForm />
      <BlogPreview />
      <BusinessMap />
      <Footer />
    </main>
  );
}

import React, { useState, useEffect, useRef } from "react";
import { motion, useInView } from "motion/react";

const stats = [
  { label: "عضو نشط", value: 15000, suffix: "+" },
  { label: "سنة خبرة", value: 12, suffix: "" },
  { label: "دورة تدريبية", value: 350, suffix: "+" },
];

function Counter({ value, suffix }) {
  const [count, setCount] = useState(0);
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true });

  useEffect(() => {
    if (isInView) {
      let start = 0;
      const end = value;
      const duration = 2000;
      const increment = Math.ceil(end / (duration / 16));

      const timer = setInterval(() => {
        start += increment;
        if (start >= end) {
          setCount(end);
          clearInterval(timer);
        } else {
          setCount(start);
        }
      }, 16);
      return () => clearInterval(timer);
    }
  }, [isInView, value]);

  return (
    <span
      ref={ref}
      className="text-5xl md:text-7xl font-bold gold-gradient font-amiri"
    >
      {count.toLocaleString()}
      {suffix}
    </span>
  );
}

export default function Stats() {
  return (
    <section className="py-20 bg-[#0A0A0B] border-y border-[#D4AF37]/10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-12 text-center">
          {stats.map((stat, idx) => (
            <div key={idx}>
              <Counter value={stat.value} suffix={stat.suffix} />
              <p className="text-[#E5E0D8]/60 text-lg mt-4 font-medium uppercase tracking-widest">
                {stat.label}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

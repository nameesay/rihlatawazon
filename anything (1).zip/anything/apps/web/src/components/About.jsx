import React from "react";
import { motion } from "motion/react";
import { Target, Compass, Zap } from "lucide-react";

const pillars = [
  {
    title: "الرؤية",
    desc: "تمكين آلاف المغاربة من تحقيق الاستقلال المالي والحرية الشخصية.",
    icon: <Target className="text-[#D4AF37]" size={40} />,
  },
  {
    title: "الرسالة",
    desc: "تقديم أفضل المنتجات الصحية والفرص الريادية لبناء مجتمع حيوي وناجح.",
    icon: <Compass className="text-[#D4AF37]" size={40} />,
  },
  {
    title: "المنهج",
    desc: "نظام تدريبي مكثف ودعم مستمر يضمن لك النمو السريع والمستدام.",
    icon: <Zap className="text-[#D4AF37]" size={40} />,
  },
];

export default function About() {
  return (
    <section id="about" className="py-24 bg-[#0A0A0B]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center mb-20">
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2"
          >
            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1560250097-0b93528c311a?q=80&w=1974&auto=format&fit=crop"
                alt="Brand Story"
                className="rounded-2xl border-2 border-[#D4AF37]/30 shadow-2xl shadow-[#D4AF37]/10"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#D4AF37] p-8 rounded-2xl hidden md:block">
                <p className="text-[#0A0A0B] font-bold text-xl italic">
                  "النجاح ليس صدفة، بل هو قرار تأخذه اليوم."
                </p>
              </div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="lg:w-1/2"
          >
            <h2 className="text-sm font-bold tracking-[0.2em] text-[#D4AF37] mb-4 uppercase">
              قصتي وهدفي
            </h2>
            <h3 className="text-4xl md:text-5xl font-bold text-[#E5E0D8] mb-6 leading-tight font-amiri">
              أقود ثورة ريادية <br />
              في المغرب منذ 10 سنوات
            </h3>
            <p className="text-[#E5E0D8]/70 text-lg leading-relaxed mb-8">
              بدأت رحلتي مع DXN من الصفر، واليوم أقود شبكة تضم آلاف الأشخاص
              الطموحين. شغفي هو مساعدتك على تخطي عقباتك المالية وبناء مشروعك
              الخاص الذي يمنحك الوقت والحرية التي تستحقها.
            </p>
          </motion.div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {pillars.map((pillar, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-[#0A0A0B] p-10 rounded-3xl border border-[#D4AF37]/20 hover:border-[#D4AF37] transition-all group"
            >
              <div className="mb-6 transform group-hover:scale-110 transition-transform">
                {pillar.icon}
              </div>
              <h4 className="text-2xl font-bold text-[#E5E0D8] mb-4 font-amiri">
                {pillar.title}
              </h4>
              <p className="text-[#E5E0D8]/60 leading-relaxed">{pillar.desc}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

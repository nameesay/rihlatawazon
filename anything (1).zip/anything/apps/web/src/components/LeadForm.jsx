import React, { useState } from "react";
import { useForm } from "react-hook-form";
import { motion, AnimatePresence } from "motion/react";
import { toast } from "sonner";
import { ChevronLeft, ChevronRight, CheckCircle2 } from "lucide-react";

export default function LeadForm() {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    trigger,
    formState: { errors },
  } = useForm();

  const nextStep = async () => {
    let fields = [];
    if (step === 1) fields = ["name"];
    if (step === 2) fields = ["phone"];

    const isValid = await trigger(fields);
    if (isValid) setStep(step + 1);
  };

  const prevStep = () => setStep(step - 1);

  const onSubmit = async (data) => {
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/leads", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        setSubmitted(true);
        toast.success("شكراً لاهتمامك! سنتواصل معك قريباً.");
      } else {
        throw new Error("Failed to submit");
      }
    } catch (error) {
      toast.error("عذراً، حدث خطأ ما. يرجى المحاولة لاحقاً.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="text-center py-20 bg-[#111112] rounded-3xl border border-[#D4AF37]/20 max-w-2xl mx-auto">
        <div className="flex justify-center mb-6">
          <CheckCircle2 size={80} className="text-[#D4AF37] animate-bounce" />
        </div>
        <h3 className="text-3xl font-bold text-[#E5E0D8] mb-4 font-amiri">
          تم استلام طلبك بنجاح!
        </h3>
        <p className="text-[#E5E0D8]/60 text-lg">
          سيقوم فريقنا بالتواصل معك عبر الواتساب في أقرب وقت ممكن.
        </p>
      </div>
    );
  }

  return (
    <section id="contact" className="py-24 bg-[#0A0A0B]">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-[#111112] rounded-3xl border border-[#D4AF37]/20 p-8 md:p-12 shadow-2xl">
          <div className="mb-10">
            <h2 className="text-3xl md:text-4xl font-bold text-[#E5E0D8] mb-4 font-amiri text-center">
              انضم إلى فريق النخبة
            </h2>
            <p className="text-[#E5E0D8]/60 text-center mb-8">
              أكمل الخطوات التالية لنعرف كيف يمكننا مساعدتك بشكل أفضل.
            </p>

            {/* Progress Bar */}
            <div className="h-2 bg-[#D4AF37]/10 rounded-full mb-8 relative">
              <motion.div
                className="absolute h-full bg-[#D4AF37] rounded-full shadow-[0_0_10px_#D4AF37]"
                initial={{ width: "0%" }}
                animate={{ width: `${(step / 3) * 100}%` }}
                transition={{ duration: 0.5 }}
              />
            </div>
            <div className="flex justify-between text-xs font-bold text-[#D4AF37] uppercase tracking-widest px-1">
              <span>الاسم</span>
              <span>الهاتف</span>
              <span>الاهتمام</span>
            </div>
          </div>

          <form onSubmit={handleSubmit(onSubmit)}>
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block text-[#E5E0D8] mb-3 font-bold text-lg">
                      ما هو اسمك الكامل؟
                    </label>
                    <input
                      {...register("name", {
                        required: "يرجى إدخال اسمك الكامل",
                      })}
                      placeholder="أدخل اسمك هنا..."
                      className="w-full bg-[#0A0A0B] border border-[#D4AF37]/30 rounded-xl px-6 py-4 text-[#E5E0D8] focus:border-[#D4AF37] outline-none transition-all text-xl"
                    />
                    {errors.name && (
                      <p className="text-red-500 mt-2 text-sm">
                        {errors.name.message}
                      </p>
                    )}
                  </div>
                  <button
                    type="button"
                    onClick={nextStep}
                    className="w-full bg-[#D4AF37] text-[#0A0A0B] py-4 rounded-xl font-bold text-xl hover:bg-[#F1D592] transition-all flex items-center justify-center gap-2"
                  >
                    الخطوة التالية <ChevronLeft size={24} />
                  </button>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block text-[#E5E0D8] mb-3 font-bold text-lg">
                      رقم الهاتف (واتساب)
                    </label>
                    <input
                      {...register("phone", {
                        required: "يرجى إدخال رقم هاتفك",
                        pattern: {
                          value: /^[0-9+ ]+$/,
                          message: "رقم غير صالح",
                        },
                      })}
                      placeholder="06XXXXXXXX"
                      dir="ltr"
                      className="w-full bg-[#0A0A0B] border border-[#D4AF37]/30 rounded-xl px-6 py-4 text-[#E5E0D8] focus:border-[#D4AF37] outline-none transition-all text-xl text-right"
                    />
                    {errors.phone && (
                      <p className="text-red-500 mt-2 text-sm">
                        {errors.phone.message}
                      </p>
                    )}
                  </div>
                  <div className="flex gap-4">
                    <button
                      type="button"
                      onClick={prevStep}
                      className="flex-1 border border-[#D4AF37]/30 text-[#D4AF37] py-4 rounded-xl font-bold"
                    >
                      السابق
                    </button>
                    <button
                      type="button"
                      onClick={nextStep}
                      className="flex-[2] bg-[#D4AF37] text-[#0A0A0B] py-4 rounded-xl font-bold text-xl flex items-center justify-center gap-2"
                    >
                      التالي <ChevronLeft size={24} />
                    </button>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div>
                    <label className="block text-[#E5E0D8] mb-4 font-bold text-lg">
                      ما هو مستوى اهتمامك؟
                    </label>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      {["مستكشف", "جاد في البدء", "طموح للقيادة"].map(
                        (level) => (
                          <label
                            key={level}
                            className="relative cursor-pointer group"
                          >
                            <input
                              type="radio"
                              {...register("interest_level", {
                                required: true,
                              })}
                              value={level}
                              className="peer sr-only"
                            />
                            <div className="p-6 bg-[#0A0A0B] border border-[#D4AF37]/30 rounded-xl text-center text-[#E5E0D8] peer-checked:bg-[#D4AF37] peer-checked:text-[#0A0A0B] transition-all group-hover:border-[#D4AF37]">
                              <span className="font-bold">{level}</span>
                            </div>
                          </label>
                        ),
                      )}
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <button
                      type="button"
                      onClick={prevStep}
                      className="flex-1 border border-[#D4AF37]/30 text-[#D4AF37] py-4 rounded-xl font-bold"
                    >
                      السابق
                    </button>
                    <button
                      type="submit"
                      disabled={isSubmitting}
                      className="flex-[2] bg-[#D4AF37] text-[#0A0A0B] py-4 rounded-xl font-bold text-xl flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      {isSubmitting ? "جاري الإرسال..." : "تأكيد الانضمام"}{" "}
                      <CheckCircle2 size={24} />
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </form>
        </div>
      </div>
    </section>
  );
}

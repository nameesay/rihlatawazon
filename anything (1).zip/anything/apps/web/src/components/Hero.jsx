import React from "react";
import { motion } from "motion/react";

export default function Hero() {
  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden bg-obsidian"
    >
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "radial-gradient(circle at 2px 2px, var(--gold) 1px, transparent 0)",
            backgroundSize: "40px 40px",
          }}
        />
      </div>

      <div className="container mx-auto px-6 py-20 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Right side - Text content (RTL) */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            className="order-2 lg:order-1 text-right"
          >
            {/* Gold accent badge */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="inline-block mb-6 px-6 py-2 bg-gold/10 border border-gold/30 rounded-full"
            >
              <span className="text-gold font-arabic-sans text-sm tracking-wide">
                قائدة DXN في المغرب
              </span>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 text-[#E5E0D8] leading-tight"
            >
              اصنع <span className="gold-gradient">نجاحك الخاص</span> في عالم
              DXN
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="text-lg md:text-xl text-[#E5E0D8]/80 mb-8 leading-relaxed max-w-xl mr-auto"
            >
              انضم إلى أكبر شبكة ريادية في المغرب وكن القائد الذي لطالما حلمت
              به. استقرار مالي وحرية وقت في انتظارك.
            </motion.p>

            {/* Quote box */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.7 }}
              className="bg-[#D4AF37]/10 border-r-4 border-[#D4AF37] p-6 mb-8 max-w-xl mr-auto"
            >
              <p className="text-[#E5E0D8]/90 italic text-lg leading-relaxed">
                "النجاح ليس وجهة، بل رحلة من التميز والإصرار"
              </p>
            </motion.div>

            {/* CTA Buttons */}
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.9 }}
              className="flex flex-col md:flex-row gap-4 justify-end"
            >
              <a
                href="#contact"
                className="bg-[#D4AF37] text-[#0A0A0B] px-10 py-4 rounded-xl font-bold text-lg hover:bg-[#F1D592] transition-all transform hover:scale-105 text-center"
              >
                ابدأ رحلتك الآن
              </a>
              <a
                href="#about"
                className="border border-[#D4AF37] text-[#D4AF37] px-10 py-4 rounded-xl font-bold text-lg hover:bg-[#D4AF37]/10 transition-all text-center"
              >
                اكتشف المزيد
              </a>
            </motion.div>
          </motion.div>

          {/* Left side - Professional Image (RTL) */}
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="order-1 lg:order-2 relative"
          >
            <div className="relative">
              {/* Gold glow effect */}
              <div className="absolute -inset-4 bg-gradient-to-br from-[#D4AF37]/20 to-transparent rounded-2xl blur-2xl" />

              <div className="relative rounded-2xl overflow-hidden border-2 border-[#D4AF37]/30 shadow-2xl shadow-[#D4AF37]/10">
                <img
                  src="https://raw.createusercontent.com/19ea3d08-73fa-43b3-8687-15717bcdbb20/"
                  alt="قائدة DXN محترفة"
                  className="w-full h-auto object-cover"
                />
                {/* Subtle overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#0A0A0B]/40 via-transparent to-transparent" />
              </div>

              {/* Decorative gold corners */}
              <div className="absolute -top-6 -right-6 w-24 h-24 border-t-4 border-r-4 border-[#D4AF37]/50 rounded-tr-3xl" />
              <div className="absolute -bottom-6 -left-6 w-24 h-24 border-b-4 border-l-4 border-[#D4AF37]/50 rounded-bl-3xl" />
            </div>
          </motion.div>
        </div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.2, duration: 1 }}
        className="absolute bottom-10 left-1/2 -translate-x-1/2"
      >
        <div className="animate-bounce">
          <div className="w-1 h-12 rounded-full bg-gradient-to-b from-[#D4AF37] to-transparent" />
        </div>
      </motion.div>
    </section>
  );
}

import React from "react";
import { motion } from "motion/react";
import { Quote } from "lucide-react";

const testimonials = [
  {
    name: "محمد العلوي",
    role: "قائد فريق",
    text: "بفضل تدريب القائد، تمكنت من مضاعفة أرباحي في غضون 6 أشهر فقط. النظام بسيط وفعال.",
  },
  {
    name: "فاطمة الزهراء",
    role: "عضو نشط",
    text: "كانت رحلتي مع DXN حافلة بالتحديات، لكن الدعم المستمر هنا جعل كل شيء ممكناً.",
  },
  {
    name: "ياسين بناني",
    role: "رائد أعمال",
    text: "أفضل قرار اتخذته هو الانضمام لهذا الفريق. الاحترافية والصدق هما العنوان.",
  },
];

export default function Testimonials() {
  return (
    <section className="py-24 bg-[#0A0A0B] overflow-hidden">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-16 items-center">
          <div className="lg:w-1/2">
            <h2 className="text-sm font-bold tracking-[0.2em] text-[#D4AF37] mb-4 uppercase">
              قصص النجاح
            </h2>
            <h3 className="text-4xl md:text-5xl font-bold text-[#E5E0D8] mb-8 font-amiri leading-tight">
              ماذا يقول <br />
              شركاؤنا في النجاح؟
            </h3>
            <div className="p-10 bg-[#D4AF37] rounded-3xl relative">
              <Quote
                className="absolute top-6 right-6 text-[#0A0A0B]/20"
                size={60}
              />
              <p className="text-[#0A0A0B] text-xl font-bold italic leading-relaxed mb-6">
                "لقد غيرت DXN حياتي تماماً. لم أكن أتصور أنني سأصل لهذا المستوى
                من الاستقرار المالي في هذا العمر."
              </p>
              <div className="flex items-center gap-4">
                <img
                  src="https://i.pravatar.cc/150?u=1"
                  className="w-12 h-12 rounded-full border-2 border-[#0A0A0B]"
                  alt="Featured"
                />
                <div>
                  <h5 className="text-[#0A0A0B] font-bold">سميرة إدريسي</h5>
                  <p className="text-[#0A0A0B]/70 text-sm">قائدة ماسية</p>
                </div>
              </div>
            </div>
          </div>

          <div className="lg:w-1/2 flex flex-col gap-6">
            {testimonials.map((t, idx) => (
              <motion.div
                key={idx}
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="p-8 bg-[#111112] border border-[#D4AF37]/10 rounded-2xl hover:border-[#D4AF37]/40 transition-all"
              >
                <p className="text-[#E5E0D8]/80 mb-4 italic">"{t.text}"</p>
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] font-bold">
                    {t.name[0]}
                  </div>
                  <div>
                    <h6 className="text-[#E5E0D8] font-bold text-sm">
                      {t.name}
                    </h6>
                    <p className="text-[#D4AF37] text-xs uppercase tracking-wider">
                      {t.role}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

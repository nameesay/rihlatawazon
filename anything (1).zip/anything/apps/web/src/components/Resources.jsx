import React from "react";
import { motion } from "motion/react";
import { BookOpen, ShieldCheck, Video, Layout } from "lucide-react";

const resources = [
  { title: "كتاب القواعد الذهبية", icon: <BookOpen />, type: "PDF" },
  { title: "دورة التسويق الشبكي", icon: <Video />, type: "فيديو" },
  { title: "دليل المنتجات الصحي", icon: <ShieldCheck />, type: "دليل" },
  { title: "أدوات إدارة الفريق", icon: <Layout />, type: "أداة" },
];

export default function Resources() {
  return (
    <section id="resources" className="py-24 bg-[#0A0A0B]">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-sm font-bold tracking-[0.2em] text-[#D4AF37] mb-4 uppercase text-center">
          مركز الموارد
        </h2>
        <h3 className="text-4xl md:text-5xl font-bold text-[#E5E0D8] mb-16 font-amiri text-center">
          موارد حصرية لشركائنا
        </h3>

        <div className="flex overflow-x-auto pb-8 gap-6 no-scrollbar md:grid md:grid-cols-4 md:overflow-visible">
          {resources.map((res, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="min-w-[280px] bg-[#111112] p-8 rounded-2xl border border-[#D4AF37]/10 group hover:border-[#D4AF37] transition-all flex flex-col items-center text-center"
            >
              <div className="w-16 h-16 rounded-full bg-[#D4AF37]/10 flex items-center justify-center text-[#D4AF37] mb-6 group-hover:bg-[#D4AF37] group-hover:text-[#0A0A0B] transition-all">
                {res.icon}
              </div>
              <h4 className="text-xl font-bold text-[#E5E0D8] mb-2 font-amiri">
                {res.title}
              </h4>
              <span className="text-xs font-bold text-[#D4AF37] px-3 py-1 rounded-full bg-[#D4AF37]/10 uppercase">
                {res.type}
              </span>
              <button className="mt-8 text-sm font-bold text-[#D4AF37] hover:underline">
                تحميل الآن
              </button>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

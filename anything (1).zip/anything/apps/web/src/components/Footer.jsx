import React from "react";
import {
  Instagram,
  Twitter,
  Facebook,
  Mail,
  Phone,
  MapPin,
} from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#050505] border-t border-[#D4AF37]/10 pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-4 gap-12 mb-20">
          <div className="md:col-span-1">
            <h4 className="text-2xl font-bold gold-gradient font-amiri mb-6 tracking-wider">
              DXN LEADER
            </h4>
            <p className="text-[#E5E0D8]/60 leading-relaxed mb-6">
              بناء القادة وتمكين الطموحين في المغرب منذ سنوات. شريكك الموثوق في
              رحلة النجاح مع DXN.
            </p>
            <div className="flex gap-4">
              {[Instagram, Twitter, Facebook].map((Icon, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full bg-[#111112] border border-[#D4AF37]/20 flex items-center justify-center text-[#D4AF37] hover:bg-[#D4AF37] hover:text-[#0A0A0B] transition-all"
                >
                  <Icon size={18} />
                </a>
              ))}
            </div>
          </div>

          <div>
            <h5 className="text-[#E5E0D8] font-bold mb-6 font-amiri text-xl">
              روابط سريعة
            </h5>
            <ul className="space-y-4 text-[#E5E0D8]/60">
              {["الرئيسية", "من أنا", "خدماتي", "الموارد", "المدونة"].map(
                (item, i) => (
                  <li key={i}>
                    <a
                      href="#"
                      className="hover:text-[#D4AF37] transition-colors"
                    >
                      {item}
                    </a>
                  </li>
                ),
              )}
            </ul>
          </div>

          <div>
            <h5 className="text-[#E5E0D8] font-bold mb-6 font-amiri text-xl">
              تواصل معنا
            </h5>
            <ul className="space-y-4 text-[#E5E0D8]/60">
              <li className="flex items-center gap-3">
                <Phone size={18} className="text-[#D4AF37]" /> +212 600 000 000
              </li>
              <li className="flex items-center gap-3">
                <Mail size={18} className="text-[#D4AF37]" />{" "}
                contact@dxnleader.ma
              </li>
              <li className="flex items-center gap-3">
                <MapPin size={18} className="text-[#D4AF37]" /> الدار البيضاء،
                المغرب
              </li>
            </ul>
          </div>

          <div>
            <h5 className="text-[#E5E0D8] font-bold mb-6 font-amiri text-xl">
              النشرة البريدية
            </h5>
            <p className="text-[#E5E0D8]/60 mb-4 text-sm">
              اشترك لتصلك آخر النصائح والفرص الحصرية.
            </p>
            <div className="flex gap-2">
              <input
                type="email"
                placeholder="بريدك الإلكتروني"
                className="bg-[#111112] border border-[#D4AF37]/20 rounded-lg px-4 py-2 text-sm w-full outline-none focus:border-[#D4AF37]"
              />
              <button className="bg-[#D4AF37] text-[#0A0A0B] px-4 py-2 rounded-lg font-bold text-sm">
                اشترك
              </button>
            </div>
          </div>
        </div>

        <div className="border-t border-[#D4AF37]/10 pt-10 flex flex-col md:flex-row justify-between items-center gap-4 text-xs font-bold text-[#E5E0D8]/40 uppercase tracking-widest">
          <p>© 2026 جميع الحقوق محفوظة للقائد DXN المغرب</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-[#D4AF37]">
              سياسة الخصوصية
            </a>
            <a href="#" className="hover:text-[#D4AF37]">
              الشروط والأحكام
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}

import React from "react";
import { motion } from "motion/react";
import { Check } from "lucide-react";

const packs = [
  {
    name: "الباقة البرونزية",
    target: "للمبتدئين",
    price: "مجاناً",
    features: [
      "عضوية DXN الأساسية",
      "تدريب تمهيدي عبر واتساب",
      "دليل المنتجات الرقمي",
    ],
    highlight: false,
  },
  {
    name: "الباقة الذهبية",
    target: "للأعضاء النشطين",
    price: "2000 درهم",
    features: [
      "عضوية VIP متميزة",
      "جلسة استشارية شهرية",
      "أدوات تسويق حصرية",
      "مجموعة منتجات تجريبية",
    ],
    highlight: true,
  },
  {
    name: "نادي النخبة",
    target: "للقادة الطموحين",
    price: "اتصل بنا",
    features: [
      "تدريب قيادي مكثف (1:1)",
      "حضور مؤتمرات خاصة",
      "دعم فني وتسويقي مدار",
      "مشاركة في الأرباح",
    ],
    highlight: false,
  },
];

export default function Services() {
  return (
    <section id="services" className="py-24 bg-[#0A0A0B]">
      <div className="max-w-7xl mx-auto px-6 text-center">
        <h2 className="text-sm font-bold tracking-[0.2em] text-[#D4AF37] mb-4 uppercase">
          استثمر في نفسك
        </h2>
        <h3 className="text-4xl md:text-5xl font-bold text-[#E5E0D8] mb-16 font-amiri">
          اختر مسارك للنجاح
        </h3>

        <div className="grid md:grid-cols-3 gap-8">
          {packs.map((pack, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className={`p-10 rounded-3xl border ${pack.highlight ? "border-[#D4AF37] bg-[#D4AF37]/5 relative overflow-hidden" : "border-[#D4AF37]/20 bg-transparent"} flex flex-col`}
            >
              {pack.highlight && (
                <div className="absolute top-4 right-[-35px] bg-[#D4AF37] text-[#0A0A0B] py-1 px-12 rotate-45 text-sm font-bold">
                  الأكثر طلباً
                </div>
              )}

              <h4 className="text-[#D4AF37] font-bold text-lg mb-2">
                {pack.target}
              </h4>
              <h5 className="text-3xl font-bold text-[#E5E0D8] mb-4 font-amiri">
                {pack.name}
              </h5>
              <div className="text-4xl font-bold text-[#E5E0D8] mb-8">
                {pack.price}
              </div>

              <ul className="text-right space-y-4 mb-10 flex-grow">
                {pack.features.map((feature, fIdx) => (
                  <li
                    key={fIdx}
                    className="flex items-center gap-3 text-[#E5E0D8]/80"
                  >
                    <Check size={18} className="text-[#D4AF37] shrink-0" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <a
                href="#contact"
                className={`w-full py-4 rounded-xl font-bold transition-all ${pack.highlight ? "bg-[#D4AF37] text-[#0A0A0B] hover:bg-[#F1D592]" : "border border-[#D4AF37] text-[#D4AF37] hover:bg-[#D4AF37]/10"}`}
              >
                اختر هذه الباقة
              </a>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

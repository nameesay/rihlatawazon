import React from "react";
import { useQuery } from "@tanstack/react-query";
import { motion } from "motion/react";
import { Calendar, User, ArrowLeft } from "lucide-react";

export default function BlogPreview() {
  const { data: posts, isLoading } = useQuery({
    queryKey: ["blog-posts"],
    queryFn: async () => {
      const res = await fetch("/api/blog");
      if (!res.ok) throw new Error("Failed to fetch");
      return res.json();
    },
  });

  return (
    <section id="blog" className="py-24 bg-[#0A0A0B]">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex justify-between items-end mb-16">
          <div>
            <h2 className="text-sm font-bold tracking-[0.2em] text-[#D4AF37] mb-4 uppercase">
              المدونة
            </h2>
            <h3 className="text-4xl md:text-5xl font-bold text-[#E5E0D8] font-amiri">
              آخر المقالات والنصائح
            </h3>
          </div>
          <a
            href="/blog"
            className="hidden md:flex items-center gap-2 text-[#D4AF37] font-bold hover:underline"
          >
            عرض كل المقالات <ArrowLeft size={20} />
          </a>
        </div>

        {isLoading ? (
          <div className="grid md:grid-cols-2 gap-8">
            {[1, 2].map((i) => (
              <div
                key={i}
                className="h-96 bg-[#111112] animate-pulse rounded-3xl"
              />
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 gap-8">
            {posts?.slice(0, 2).map((post, idx) => (
              <motion.article
                key={post.id}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: idx * 0.1 }}
                className="group relative overflow-hidden rounded-3xl bg-[#111112] border border-[#D4AF37]/10 hover:border-[#D4AF37]/50 transition-all"
              >
                <div className="aspect-video overflow-hidden">
                  <img
                    src={
                      post.image_url ||
                      "https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop"
                    }
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700"
                  />
                </div>
                <div className="p-8">
                  <div className="flex gap-4 text-xs font-bold text-[#D4AF37] mb-4 uppercase tracking-wider">
                    <span className="flex items-center gap-1">
                      <Calendar size={14} />{" "}
                      {new Date(post.created_at).toLocaleDateString("ar-MA")}
                    </span>
                    <span className="flex items-center gap-1">
                      <User size={14} /> القائد
                    </span>
                  </div>
                  <h4 className="text-2xl font-bold text-[#E5E0D8] mb-4 font-amiri group-hover:text-[#D4AF37] transition-colors">
                    {post.title}
                  </h4>
                  <p className="text-[#E5E0D8]/60 mb-6 line-clamp-2">
                    {post.excerpt}
                  </p>
                  <a
                    href={`/blog/${post.slug}`}
                    className="inline-flex items-center gap-2 text-[#D4AF37] font-bold border-b border-[#D4AF37]/0 hover:border-[#D4AF37] transition-all"
                  >
                    اقرأ المزيد <ArrowLeft size={18} />
                  </a>
                </div>
              </motion.article>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}

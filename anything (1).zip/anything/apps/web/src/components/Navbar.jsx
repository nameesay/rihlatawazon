import React, { useState, useEffect } from "react";
import { Menu, X, ChevronLeft } from "lucide-react";

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "الرئيسية", href: "#hero" },
    { name: "من أنا", href: "#about" },
    { name: "خدماتي", href: "#services" },
    { name: "الموارد", href: "#resources" },
    { name: "المدونة", href: "#blog" },
    { name: "تواصل معي", href: "#contact" },
  ];

  return (
    <nav
      className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? "bg-[#0A0A0B]/90 backdrop-blur-md py-4 border-b border-[#D4AF37]/20" : "bg-transparent py-6"}`}
    >
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
        <div className="text-2xl font-bold gold-gradient font-amiri tracking-wider">
          DXN LEADER
        </div>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <a
              key={link.name}
              href={link.href}
              className="text-[#E5E0D8] hover:text-[#D4AF37] transition-colors text-sm font-medium"
            >
              {link.name}
            </a>
          ))}
          <a
            href="#contact"
            className="bg-[#D4AF37] text-[#0A0A0B] px-6 py-2 rounded-full text-sm font-bold hover:bg-[#F1D592] transition-colors"
          >
            انضم الآن
          </a>
        </div>

        {/* Mobile Toggle */}
        <button
          className="md:hidden text-[#D4AF37]"
          onClick={() => setIsOpen(!isOpen)}
        >
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden absolute top-full left-0 w-full bg-[#0A0A0B] border-b border-[#D4AF37]/20 py-6 px-6 animate-fade-in">
          <div className="flex flex-col gap-4">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className="text-[#E5E0D8] text-lg font-medium"
                onClick={() => setIsOpen(false)}
              >
                {link.name}
              </a>
            ))}
            <a
              href="#contact"
              className="bg-[#D4AF37] text-[#0A0A0B] text-center px-6 py-3 rounded-xl font-bold mt-4"
              onClick={() => setIsOpen(false)}
            >
              انضم الآن
            </a>
          </div>
        </div>
      )}
    </nav>
  );
}
